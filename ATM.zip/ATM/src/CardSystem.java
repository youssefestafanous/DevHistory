import java.util.HashMap;
import java.util.*;
public class CardSystem {
    private static Map<Long,Card> cardSystem;
    int length;
    public CardSystem(){
        cardSystem = new HashMap<>();
        length = 0;
    }
    public long createCard(int pin, double currentBalance, double savingsBalance){
        long first14 = (long) (Math.random() * 100000000000000L);
        long id = 5200000000000000L + first14;
        Card newCard = new Card(id, pin, savingsBalance,currentBalance);
        cardSystem.put(id, newCard);
        return id;
    }
    public Card getCard(long id){
        return cardSystem.get(id);
    }

    public void startATM(long id){
        Card temp = getCard(id);
        if (temp == null){
            System.out.println("Card Invalid");
            return;
        }
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter your card's pin");
        int pin = input.nextInt();
        int trials = 3;
        while(!temp.checkPin(pin)&&trials!=0) {
            pin = input.nextInt();
            trials--;
        }
        temp.selectAccount();
    }

    public static void main(String[] args) {
        CardSystem s = new CardSystem();
        System.out.println(s.createCard(1234,2000,4000));
        s.startATM(s.createCard(1234,2000,4000));

    }

}
