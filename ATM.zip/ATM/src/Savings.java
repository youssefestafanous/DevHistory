
public class Savings extends Account {
	public Savings(double balance){
		this.balance = balance;
	}
	public double viewBalance(int years){
		double compBal = balance;
		for(int i = years; i>0;i--){
			compBal = compBal*1.04;
		}
		return compBal;
	}
}
