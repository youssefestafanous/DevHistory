
public abstract class Account {
	double balance;
	public Account(){}
	public Account(double balance){
		this.balance = balance;
	}
	protected double withdraw(int amount){
		this.balance=balance-amount;
		return balance;
	}
	protected double deposit(int amount){
		balance+=amount;
		return balance;
	}
	public double viewBalance(){
		return balance;
	}
}
