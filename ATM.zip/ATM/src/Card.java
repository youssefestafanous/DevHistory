import java.util.Scanner;
public class Card {
	public long id;
	private int pin;
	private Savings saving;
	private Current current;
	public Card(long id, int pin, double savingsBal, double currentBal){
		this.id = id;
		this.pin = pin;
		saving = new Savings(savingsBal);
		current = new Current(currentBal);
	}
	public boolean checkPin(int pin){
		if(pin==this.pin)
			return true;
		else return false;
	}
	public void selectAccount(){
		System.out.println("Fast Cash: 1");
		System.out.println("Current Account: 2");
		System.out.println("Savings Account: 3");
		Scanner input = new Scanner(System.in);
		int type = input.nextInt();
		while(type<1||type>3){
			System.out.println("Invalid type selection. Please enter type of transaction again:");
			type = input.nextInt();
		}
		if(type == 1){
			System.out.println("How much would you like to withdraw?");
			int amount = input.nextInt();
			while(amount>current.viewBalance()+2000){
				System.out.println("You cannot overdraw on this account by more than 2000 dollars. Your current balance is: " +current.viewBalance());
				System.out.println("Please input a new amount.");
				amount = input.nextInt();
			}
			System.out.println("Your new balance is: " + current.withdraw(amount));
		}
		if(type == 2){
			System.out.println("You have selected current account. Which operation would you like to perform?");
			System.out.println("Withdraw from balance: 1");
			System.out.println("Deposit into balance: 2");
			System.out.println("View balance: 3");
			int operation = input.nextInt();
			while(operation<1||operation>3){
				System.out.println("Invalid operation selection. Please enter valid operation.");
				operation = input.nextInt();}
				if(operation == 1){
					System.out.println("How much would you like to withdraw?");
					int amount = input.nextInt();
					while(amount>current.viewBalance()+2000){
						System.out.println("You cannot overdraw on this account by more than 2000 dollars. Your current balance is: " +current.viewBalance());
						System.out.println("Please input a new amount.");
						amount = input.nextInt();
					}
					System.out.println("Your new balance is: " + current.withdraw(amount));
				}
				if(operation == 2){
					System.out.println("Place deposit amount in money tray.");
					int amount = input.nextInt();
					System.out.println("Your new balance is: " + current.deposit(amount));
				}
				if(operation == 3){
					System.out.println("Your current balance is: " +current.viewBalance());
				}
			}
		if(type == 3){
			System.out.println("You have selected Savings account. Which operation would you like to perform?");
			System.out.println("Withdraw from balance: 1");
			System.out.println("Deposit into balance: 2");
			System.out.println("View balance: 3");
			int operation = input.nextInt();
			while(operation<1||operation>3){
				System.out.println("Invalid operation selection. Please enter valid operation.");
				operation = input.nextInt();}
				if(operation == 1){
					System.out.println("How much would you like to withdraw?");
					int amount = input.nextInt();
					while(amount>saving.viewBalance()/5){
						System.out.println("You cannot withdraw more than 20% of this account. Your current balance is: " +saving.viewBalance());
						System.out.println("Please input a new amount.");
						amount = input.nextInt();
					}
					System.out.println("Your new balance is: " + saving.withdraw(amount));
				}
				if(operation == 2){
					System.out.println("Place deposit amount in money tray.");
					int amount = input.nextInt();
					System.out.println("Your new balance is: " + saving.deposit(amount));
				}
				if(operation == 3){
					System.out.println("How many years has this account been open?");
					int years = input.nextInt();
					while(years<0){
						System.out.println("Invalid Years");
						years = input.nextInt();
					}
					System.out.println("Your current balance is: " +saving.viewBalance(years));
				}
			}
		}
	public static void main(String[] args) {
		Card s = new Card(123456,1234, 1000, 4000);
		s.selectAccount();
	}
}

