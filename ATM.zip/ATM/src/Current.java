
public class Current extends Account {
	public Current(double balance){
		this.balance = balance;
	}
}
